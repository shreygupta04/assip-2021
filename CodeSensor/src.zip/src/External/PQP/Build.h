
#ifndef PQP_BUILD_H
#define PQP_BUILD_H

#include "PQP.h"

int
build_model(PQP_Model *m);

#endif
