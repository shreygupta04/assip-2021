
#ifndef PQP_TRI_H
#define PQP_TRI_H

#include "PQP_Compile.h"

struct Tri
{
  PQP_REAL p1[3];
  PQP_REAL p2[3];
  PQP_REAL p3[3];
  int id;
};

#endif
